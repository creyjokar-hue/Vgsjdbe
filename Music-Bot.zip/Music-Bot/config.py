# ==========================================================
# Copyright (c) 2026 ArtistBots
# All Rights Reserved.
#
# Project      : Music Bot by @k1ttu_darling
# Powered By   : @k1ttu_darling
# Type         : API Based Telegram Music Bot (Turso DB)
#
# Bot          : @ArtistApibot
# Channel      : https://t.me/artistbots
# DEVELOPER    : @k1ttu_darling
#
# Unauthorized copying, modification, or redistribution
# of this source code without permission is prohibited.
# ==========================================================
from os import getenv
from typing import List
from dotenv import load_dotenv

from pathlib import Path

load_dotenv()


class Config:
    def __init__(self):
        # Telegram API
        self.API_ID: int = int(getenv("API_ID", "0"))
        self.API_HASH: str = getenv("API_HASH", "")
        self.BOT_TOKEN: str = getenv("BOT_TOKEN", "")
        self.LOGGER_ID: int = int(getenv("LOGGER_ID", "0"))
        self.OWNER_ID: int = int(getenv("OWNER_ID", "0"))

        # Turso Database
        self.TURSO_DATABASE_URL: str = getenv(
            "TURSO_DATABASE_URL",
            "libsql://kittu-kittu-x.aws-ap-south-1.turso.io",
        )
        self.TURSO_AUTH_TOKEN: str = getenv(
            "TURSO_AUTH_TOKEN",
            "",
        )
        # Keep MONGO_URL alias empty for safety (no longer used)
        self.MONGO_URL: str = getenv("MONGO_DB_URI", "")

        # Limits
        self.DURATION_LIMIT: int = int(getenv("DURATION_LIMIT", "300")) * 60
        self.QUEUE_LIMIT: int = int(getenv("QUEUE_LIMIT", "30"))
        self.PLAYLIST_LIMIT: int = int(getenv("PLAYLIST_LIMIT", "20"))

        # Assistant Sessions
        self.SESSION1: str = getenv("STRING_SESSION", "")
        self.SESSION2: str = getenv("STRING_SESSION2", "")
        self.SESSION3: str = getenv("STRING_SESSION3", "")

        # Support Links
        self.SUPPORT_CHANNEL: str = getenv(
            "SUPPORT_CHANNEL", "https://t.me/k1ttu_darling"
        )
        self.SUPPORT_CHAT: str = getenv(
            "SUPPORT_CHAT", "https://t.me/k1ttu_darling"
        )

        self.UPDATE_CHANNEL: str = getenv(
            "UPDATE_CHANNEL", "https://t.me/shinzu_updates"
        )
        self.DEVELOPER: str = getenv("DEVELOPER", "https://t.me/k1ttu_darling")

        # Excluded Chats
        self.EXCLUDED_CHATS: List[int] = self._parse_excluded_chats()

        # Feature Flags
        self.AUTO_END: bool = self._str_to_bool(getenv("AUTO_END", "False"))
        self.AUTO_LEAVE: bool = self._str_to_bool(getenv("AUTO_LEAVE", "False"))
        self.THUMB_GEN: bool = self._str_to_bool(getenv("THUMB_GEN", "True"))
        self.VIDEO_PLAY: bool = self._str_to_bool(getenv("VIDEO_PLAY", "True"))
        self.VIDEO_MAX_HEIGHT: int = self._parse_video_height()

        # ArtistBots API
        self.ARTISTBOTS_API_URL: str = getenv(
            "ARTISTBOTS_API_URL", "https://music.artistbots.workers.dev"
        )
        self.ARTISTBOTS_KEY: str = getenv("ARTISTBOTS_KEY", "")
        self.ENABLE_API: bool = self._str_to_bool(getenv("ENABLE_API", "True"))
        self.ENABLE_COOKIES_FALLBACK: bool = self._str_to_bool(
            getenv("ENABLE_COOKIES_FALLBACK", "True")
        )
        self.API_TIMEOUT: int = int(getenv("API_TIMEOUT", "60"))
        self.API_STREAM_TIMEOUT: int = int(getenv("API_STREAM_TIMEOUT", "300"))

        # YouTube Cookies
        self.COOKIES_URL: List[str] = self._parse_cookies()

        # Images
        _banner = str(Path(__file__).resolve().parent / "ArtistMusic" / "assets" / "olivia_banner.jpg")
        self.DEFAULT_THUMB: str = getenv("DEFAULT_THUMB", _banner)
        self.PING_IMG: str = getenv("PING_IMG", _banner)
        self.START_IMG: str = getenv("START_IMG", _banner)
        self.RADIO_IMG: str = getenv("RADIO_IMG", _banner)

        # Moderation
        self.EXCLUDED_USERNAMES: List[str] = getenv(
            "EXCLUDED_USERNAMES", ""
        ).split()

    def _parse_video_height(self) -> int:
        default_height = 1080
        raw_value = getenv("VIDEO_MAX_HEIGHT", str(default_height))
        try:
            height = int(raw_value)
        except (TypeError, ValueError):
            return default_height
        if height <= 0:
            return 0
        return max(480, min(height, 2160))

    def _parse_excluded_chats(self) -> List[int]:
        excluded = getenv("EXCLUDED_CHATS", "")
        if not excluded:
            return []
        chat_ids = []
        for chat_id in excluded.split(","):
            chat_id = chat_id.strip()
            if chat_id.lstrip("-").isdigit():
                chat_ids.append(int(chat_id))
        return chat_ids

    def _parse_cookies(self) -> List[str]:
        cookie_str = getenv("COOKIE_URL", "")
        if not cookie_str:
            return []
        valid_sources = ["batbin.me", "pastebin.com", "paste.ee", "rentry.co"]
        return [
            url.strip()
            for url in cookie_str.split()
            if url.strip() and any(source in url for source in valid_sources)
        ]

    @staticmethod
    def _str_to_bool(value: str) -> bool:
        return value.lower() in ("true", "1", "yes", "y", "on")

    def check(self) -> None:
        required_vars = {
            "API_ID": self.API_ID,
            "API_HASH": self.API_HASH,
            "BOT_TOKEN": self.BOT_TOKEN,
            "TURSO_DATABASE_URL": self.TURSO_DATABASE_URL,
            "TURSO_AUTH_TOKEN": self.TURSO_AUTH_TOKEN,
            "LOGGER_ID": self.LOGGER_ID,
            "OWNER_ID": self.OWNER_ID,
        }
        missing = [
            name
            for name, value in required_vars.items()
            if not value or (isinstance(value, int) and value == 0)
        ]
        if missing:
            raise SystemExit(f"Missing required env vars: {', '.join(missing)}")

        # STRING_SESSION can be empty at start if using /connect later
        if not self.SESSION1:
            print(
                "Warning: STRING_SESSION not set. "
                "Use /connect in bot DM after start, or set STRING_SESSION in .env"
            )

        if self.ENABLE_API and not self.ARTISTBOTS_KEY:
            print("Warning: ENABLE_API is True but ARTISTBOTS_KEY is not set")


config = Config()
