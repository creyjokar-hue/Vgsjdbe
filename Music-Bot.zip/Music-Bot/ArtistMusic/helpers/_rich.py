# ==========================================================
# Rich Message helper (Telegram Bot API 10.1 sendRichMessage)
# Project : Music Bot by @k1ttu_darling
# Direct HTTP calls, so it works with any MTProto library.
# Every function fails SAFE: on any error it returns None and the
# caller falls back to the normal message flow.
# ==========================================================
import asyncio
import json
import logging
import re
from typing import Optional

import aiohttp

from ArtistMusic import config

logger = logging.getLogger("ArtistMusic")

_API = "https://api.telegram.org/bot{token}/{method}"
_ESC = set("\\`*_{}[]()#+-.!|<>~&")

# (chat_id, rich_message_id) -> photo_message_id (thumbnail sent above the rich message)
PHOTO_OF: dict = {}

# If Telegram says sendRichMessage is unknown, stop trying for this run.
_DISABLED = False


def esc(text) -> str:
    """Escape text for Rich Markdown."""
    return "".join("\\" + c if c in _ESC else c for c in str(text or ""))


def user_md(user) -> str:
    """media.user can be an HTML anchor, a markdown mention or plain text."""
    s = str(user or "")
    m = re.search(r'<a\s+href=["\']?([^"\'>\s]+)["\']?>(.*?)</a>', s, re.S)
    if m:
        return f"[{esc(m.group(2))}]({m.group(1)})"
    m = re.search(r"\[(.*?)\]\((.*?)\)", s, re.S)
    if m:
        return f"[{esc(m.group(1))}]({m.group(2)})"
    return esc(re.sub(r"<.*?>", "", s)) or "Unknown"


def thumb_url(media) -> Optional[str]:
    """Original YouTube thumbnail for a media/track (None if not a YouTube id)."""
    t = getattr(media, "thumbnail", None)
    if t and str(t).startswith("http"):
        return t
    vid = str(getattr(media, "id", "") or "")
    if re.fullmatch(r"[\w-]{11}", vid):
        return f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
    return None


def _style(btn) -> Optional[str]:
    st = getattr(btn, "style", None)
    if not st:
        return None
    name = getattr(st, "name", None) or str(st)
    name = name.split(".")[-1].lower()
    return name if name in ("primary", "success", "danger") else None


def kb_json(markup) -> Optional[dict]:
    """Convert a pyrogram/kurigram InlineKeyboardMarkup into Bot API JSON."""
    if not markup:
        return None
    rows = []
    for row in markup.inline_keyboard:
        out = []
        for b in row:
            d = {"text": b.text}
            cb = getattr(b, "callback_data", None)
            if cb is not None:
                d["callback_data"] = cb.decode() if isinstance(cb, bytes) else str(cb)
            elif getattr(b, "url", None):
                d["url"] = b.url
            elif getattr(b, "copy_text", None):
                ct = b.copy_text
                d["copy_text"] = {"text": getattr(ct, "text", ct)}
            else:
                continue
            st = _style(b)
            if st:
                d["style"] = st
            out.append(d)
        if out:
            rows.append(out)
    return {"inline_keyboard": rows}


async def _call(method: str, payload: dict) -> Optional[dict]:
    global _DISABLED
    if _DISABLED:
        return None
    url = _API.format(token=config.BOT_TOKEN, method=method)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(
                url, json=payload, timeout=aiohttp.ClientTimeout(total=25)
            ) as r:
                data = await r.json(content_type=None)
        if data.get("ok"):
            return data["result"]
        desc = str(data.get("description", ""))
        if data.get("error_code") == 404 or "method" in desc.lower() and "not" in desc.lower():
            _DISABLED = True
            logger.warning("Rich messages not supported by this Bot API server, using normal messages.")
        elif data.get("error_code") == 429:
            wait = int(data.get("parameters", {}).get("retry_after", 2))
            await asyncio.sleep(wait + 1)
            return await _call(method, payload)
        else:
            logger.warning(f"{method} failed: {desc[:200]}")
    except Exception as e:
        logger.warning(f"{method} error: {type(e).__name__}: {e}")
    return None


async def send_rich(
    chat_id: int,
    markdown: str,
    reply_markup=None,
    reply_to: Optional[int] = None,
) -> Optional[int]:
    """Send a rich message. Returns message_id or None (caller must fall back)."""
    payload = {"chat_id": chat_id, "rich_message": {"markdown": markdown}}
    kb = kb_json(reply_markup)
    if kb:
        payload["reply_markup"] = kb
    if reply_to:
        payload["reply_parameters"] = {
            "message_id": reply_to,
            "allow_sending_without_reply": True,
        }
    res = await _call("sendRichMessage", payload)
    return res.get("message_id") if res else None


async def delete_pair(app, chat_id: int, message_id: Optional[int]) -> None:
    """Delete a rich message together with the thumbnail photo above it."""
    if not message_id:
        return
    ids = [message_id]
    photo = PHOTO_OF.pop((chat_id, message_id), None)
    if photo:
        ids.append(photo)
    try:
        await app.delete_messages(chat_id=chat_id, message_ids=ids, revoke=True)
    except Exception:
        pass


# ── Premium texts ─────────────────────────────────────────────────────────
_FOOT = "❤ *Powered by* [@k1ttu\\_darling](https://t.me/k1ttu_darling)"


def now_playing_md(media) -> str:
    title = esc(media.title)
    link = media.url or ""
    live = getattr(media, "is_live", False)
    dur = "🔴 LIVE" if live else esc(media.duration)
    return (
        "## 🎧 Now Playing\n\n"
        f"### [{title}]({link})\n\n"
        f"> 🕔 **Duration:** {dur}\n"
        ">\n"
        f"> 👤 **Requested by:** {user_md(media.user)}\n\n"
        "---\n\n"
        f"{_FOOT}"
    )


def queued_md(media, position: int) -> str:
    title = esc(media.title)
    link = media.url or ""
    live = getattr(media, "is_live", False)
    dur = "🔴 LIVE" if live else esc(media.duration)
    return (
        "## ➕ Added to Queue\n\n"
        f"### [{title}]({link})\n\n"
        f"> 📍 **Position:** \\#{position}\n"
        ">\n"
        f"> 🕔 **Duration:** {dur}\n"
        ">\n"
        f"> 👤 **Requested by:** {user_md(media.user)}\n\n"
        "---\n\n"
        f"{_FOOT}"
    )
