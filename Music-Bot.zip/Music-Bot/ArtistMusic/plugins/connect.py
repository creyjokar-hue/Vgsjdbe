# ==========================================================
# Music Bot by @k1ttu_darling
# /connect — save assistant string session via bot DM
# ==========================================================

from pyrogram import filters, types, enums

from ArtistMusic import app, config, db, lang
from ArtistMusic.helpers import utils


@app.on_message(filters.command(["connect", "assconnect", "session"]) & filters.private)
@lang.language()
async def connect_assistant(_, m: types.Message):
    """
    Owner/sudo can connect assistant string session from bot DM.

    Usage:
      /connect <string_session>
      /connect 2 <string_session>   (slot 2)
      /connect 3 <string_session>   (slot 3)
    """
    try:
        await m.delete()
    except Exception:
        pass

    user_id = m.from_user.id if m.from_user else 0
    if user_id != config.OWNER_ID and user_id not in getattr(app, "sudoers", set()):
        return await m.reply_text(
            "❌ Only **Owner / Sudo** can use /connect."
        )

    args = m.command[1:] if m.command else []
    if not args:
        return await m.reply_text(
            "**🔗 Assistant Connect**\n\n"
            "Bot ke DM me bhejo:\n\n"
            "`/connect <STRING_SESSION>`\n"
            "`/connect 2 <STRING_SESSION>`  ← slot 2\n"
            "`/connect 3 <STRING_SESSION>`  ← slot 3\n\n"
            "**String Session kaise banaye:**\n"
            "1. @StringSessionBot ya @PyrogramStringBot pe jao\n"
            "2. Pyrogram select karo\n"
            "3. API_ID + API_HASH do (my.telegram.org se)\n"
            "4. Phone + OTP do\n"
            "5. Jo session mile use yahan paste karo\n\n"
            "⚠️ Session save hone ke baad **bot restart** karna hoga "
            "taaki assistant load ho."
        )

    slot = 1
    session = None

    if args[0].isdigit() and len(args) >= 2:
        slot = int(args[0])
        if slot not in (1, 2, 3):
            return await m.reply_text("❌ Slot only 1, 2 or 3.")
        session = " ".join(args[1:]).strip()
    else:
        session = " ".join(args).strip()

    if not session or len(session) < 50:
        return await m.reply_text(
            "❌ Invalid session string. Bahut chhota hai.\n"
            "Pyrogram string session paste karo."
        )

    # basic sanity — pyrogram sessions are long base64-like
    if " " in session and len(session.split()) > 3:
        return await m.reply_text(
            "❌ Session string me extra spaces / text lag raha hai.\n"
            "Sirf pure session string bhejo."
        )

    try:
        await db.save_session(session, slot=slot)
    except Exception as e:
        return await m.reply_text(f"❌ DB save failed: `{e}`")

    # also set in memory for current process (may still need restart for userbot boot)
    if slot == 1:
        config.SESSION1 = session
    elif slot == 2:
        config.SESSION2 = session
    else:
        config.SESSION3 = session

    await m.reply_text(
        f"✅ **Assistant session saved** (slot `{slot}`)\n\n"
        f"• Turso DB me store ho gaya\n"
        f"• Ab bot **restart** karo taaki assistant connect ho\n\n"
        f"`bash start` ya hosting panel se restart\n\n"
        f"Restart ke baad assistant multiple groups me "
        f"voice chat join karke play kar sakta hai."
    )


@app.on_message(filters.command(["disconnect", "rmsession"]) & filters.private)
@lang.language()
async def disconnect_assistant(_, m: types.Message):
    """Remove saved session from Turso DB."""
    try:
        await m.delete()
    except Exception:
        pass

    user_id = m.from_user.id if m.from_user else 0
    if user_id != config.OWNER_ID and user_id not in getattr(app, "sudoers", set()):
        return await m.reply_text("❌ Only Owner / Sudo.")

    args = m.command[1:] if m.command else []
    slot = int(args[0]) if args and args[0].isdigit() else 1
    if slot not in (1, 2, 3):
        return await m.reply_text("❌ Slot only 1, 2 or 3.")

    try:
        await db._exec("DELETE FROM sessions WHERE id = ?", (slot,))
    except Exception as e:
        return await m.reply_text(f"❌ Failed: `{e}`")

    if slot == 1:
        config.SESSION1 = ""
    elif slot == 2:
        config.SESSION2 = ""
    else:
        config.SESSION3 = ""

    await m.reply_text(
        f"✅ Session slot `{slot}` removed from DB.\n"
        "Restart bot to fully disconnect assistant."
    )


@app.on_message(filters.command(["sessions", "mysessions"]) & filters.private)
@lang.language()
async def list_sessions(_, m: types.Message):
    user_id = m.from_user.id if m.from_user else 0
    if user_id != config.OWNER_ID and user_id not in getattr(app, "sudoers", set()):
        return await m.reply_text("❌ Only Owner / Sudo.")

    try:
        rows = await db.get_all_sessions()
    except Exception as e:
        return await m.reply_text(f"❌ `{e}`")

    if not rows:
        return await m.reply_text(
            "📭 Koi saved session nahi.\n"
            "Use `/connect <string_session>`"
        )

    text = "**Saved Assistant Sessions**\n\n"
    for sid, sess in rows:
        preview = sess[:20] + "..." + sess[-10:] if len(sess) > 35 else sess
        text += f"• Slot `{sid}`: `{preview}`\n"
    text += "\nRestart bot after changes."
    await m.reply_text(text)
