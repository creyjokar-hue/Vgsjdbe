# ==========================================================
# Copyright (c) 2026 ArtistBots
# All Rights Reserved.
#
# Project      : Music Bot by @k1ttu_darling
# Powered By   : @k1ttu_darling
# Type         : API Based Telegram Music Bot (Turso DB)
#
# DEVELOPER    : @k1ttu_darling
# ==========================================================

from random import randint
from time import time
import asyncio
import logging
import json

from ArtistMusic import config, logger, userbot


class NoAssistantAvailable(Exception):
    """Raised when no assistant client is currently connected."""
    pass


class MongoDB:
    """Turso (libSQL) backed database with same interface as original MongoDB class."""

    def __init__(self):
        self._conn = None
        self.admin_list = {}
        self.admin_cache_time = {}
        self.active_calls = {}
        self.blacklisted = []
        self.notified = []
        self.logger = False
        self.maintenance = False
        self.gbanned_users = []
        self.vplay_enabled = config.VIDEO_PLAY
        self.assistant = {}
        self.auth = {}
        self.chats = []
        self.lang = {}
        self.play_mode = []
        self.force_mode = []
        self.users = []
        self.user_lang = {}

    def _connect_sync(self):
        import libsql
        url = config.TURSO_DATABASE_URL
        token = config.TURSO_AUTH_TOKEN
        if not url or not token:
            raise SystemExit(
                "Missing TURSO_DATABASE_URL or TURSO_AUTH_TOKEN in env/.env"
            )
        return libsql.connect(database=url, auth_token=token)

    async def _exec(self, sql: str, args=None):
        def run():
            conn = self._conn
            if args:
                cur = conn.execute(sql, args)
            else:
                cur = conn.execute(sql)
            conn.commit()
            return cur
        return await asyncio.to_thread(run)

    async def _fetchone(self, sql: str, args=None):
        def run():
            conn = self._conn
            if args:
                cur = conn.execute(sql, args)
            else:
                cur = conn.execute(sql)
            return cur.fetchone()
        return await asyncio.to_thread(run)

    async def _fetchall(self, sql: str, args=None):
        def run():
            conn = self._conn
            if args:
                cur = conn.execute(sql, args)
            else:
                cur = conn.execute(sql)
            return cur.fetchall()
        return await asyncio.to_thread(run)

    async def _init_schema(self):
        schema = """
        CREATE TABLE IF NOT EXISTS kv (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS auth (
            chat_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            PRIMARY KEY (chat_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS assistants (
            chat_id INTEGER PRIMARY KEY,
            num INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS chats (
            chat_id INTEGER PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS lang (
            chat_id INTEGER PRIMARY KEY,
            lang TEXT NOT NULL DEFAULT 'en'
        );
        CREATE TABLE IF NOT EXISTS user_lang (
            user_id INTEGER PRIMARY KEY,
            lang TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS play_mode (
            chat_id INTEGER PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS force_mode (
            chat_id INTEGER PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS sudoers (
            user_id INTEGER PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY,
            session_string TEXT NOT NULL,
            created_at REAL
        );
        """
        def run():
            self._conn.executescript(schema)
            self._conn.commit()
        await asyncio.to_thread(run)

    async def _kv_get(self, key: str, default=None):
        row = await self._fetchone("SELECT value FROM kv WHERE key = ?", (key,))
        if not row:
            return default
        try:
            return json.loads(row[0])
        except Exception:
            return row[0]

    async def _kv_set(self, key: str, value):
        val = json.dumps(value) if not isinstance(value, str) else value
        await self._exec(
            "INSERT INTO kv (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, val),
        )

    async def _kv_del(self, key: str):
        await self._exec("DELETE FROM kv WHERE key = ?", (key,))

    async def connect(self) -> None:
        max_retries = 3
        retry_delay = 5
        for attempt in range(1, max_retries + 1):
            try:
                start = time()
                self._conn = await asyncio.to_thread(self._connect_sync)
                await self._init_schema()
                await self._fetchone("SELECT 1")
                logger.info(
                    f"✅ Turso DB connection successful. ({time() - start:.2f}s)"
                )
                await self.load_cache()
                return
            except Exception as e:
                if attempt < max_retries:
                    wait_time = retry_delay * (2 ** (attempt - 1))
                    logger.warning(
                        f"Turso connection attempt {attempt}/{max_retries} failed: "
                        f"{type(e).__name__}: {e}. Retrying in {wait_time}s..."
                    )
                    await asyncio.sleep(wait_time)
                else:
                    raise SystemExit(
                        f"Turso DB connection failed after {max_retries} attempts: "
                        f"{type(e).__name__}: {e}"
                    ) from e

    async def close(self) -> None:
        if self._conn:
            await asyncio.to_thread(self._conn.close)
            logger.info("Turso DB connection closed.")

    async def get_call(self, chat_id: int) -> bool:
        return chat_id in self.active_calls

    async def add_call(self, chat_id: int) -> None:
        self.active_calls[chat_id] = 1

    async def remove_call(self, chat_id: int) -> None:
        self.active_calls.pop(chat_id, None)

    async def playing(self, chat_id: int, paused: bool = None) -> bool | None:
        if paused is not None:
            self.active_calls[chat_id] = int(not paused)
        return bool(self.active_calls.get(chat_id, 0))

    async def get_admins(self, chat_id: int, reload: bool = False) -> list[int]:
        from ArtistMusic.helpers._admins import reload_admins
        now = time()
        if (
            not reload
            and chat_id in self.admin_list
            and now - self.admin_cache_time.get(chat_id, 0) < 900
        ):
            return self.admin_list[chat_id]
        admins = await reload_admins(chat_id)
        self.admin_list[chat_id] = admins
        self.admin_cache_time[chat_id] = now
        return admins

    async def _get_auth(self, chat_id: int) -> set[int]:
        if chat_id not in self.auth:
            rows = await self._fetchall(
                "SELECT user_id FROM auth WHERE chat_id = ?", (chat_id,)
            )
            self.auth[chat_id] = {r[0] for r in rows}
        return self.auth[chat_id]

    async def is_auth(self, chat_id: int, user_id: int) -> bool:
        return user_id in await self._get_auth(chat_id)

    async def add_auth(self, chat_id: int, user_id: int) -> None:
        auth_set = await self._get_auth(chat_id)
        if user_id not in auth_set:
            auth_set.add(user_id)
            await self._exec(
                "INSERT OR IGNORE INTO auth (chat_id, user_id) VALUES (?, ?)",
                (chat_id, user_id),
            )

    async def rm_auth(self, chat_id: int, user_id: int) -> None:
        auth_set = await self._get_auth(chat_id)
        if user_id in auth_set:
            auth_set.discard(user_id)
            await self._exec(
                "DELETE FROM auth WHERE chat_id = ? AND user_id = ?",
                (chat_id, user_id),
            )

    async def set_assistant(self, chat_id: int) -> int:
        if not userbot.clients:
            raise NoAssistantAvailable(
                "No assistant clients are currently connected. "
                "Use /connect in bot DM or set STRING_SESSION in .env"
            )
        num = randint(1, len(userbot.clients))
        await self._exec(
            "INSERT INTO assistants (chat_id, num) VALUES (?, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET num = excluded.num",
            (chat_id, num),
        )
        self.assistant[chat_id] = num
        return num

    async def get_assistant(self, chat_id: int):
        from ArtistMusic import tune
        if chat_id not in self.assistant:
            row = await self._fetchone(
                "SELECT num FROM assistants WHERE chat_id = ?", (chat_id,)
            )
            num = row[0] if row else await self.set_assistant(chat_id)
            self.assistant[chat_id] = num
        if self.assistant[chat_id] > len(userbot.clients):
            num = await self.set_assistant(chat_id)
            self.assistant[chat_id] = num
        return tune.clients[self.assistant[chat_id] - 1]

    async def get_client(self, chat_id: int):
        if chat_id not in self.assistant:
            await self.get_assistant(chat_id)
        if self.assistant[chat_id] > len(userbot.clients):
            await self.set_assistant(chat_id)
        available_clients = {}
        if hasattr(userbot, "one") and userbot.one in userbot.clients:
            available_clients[1] = userbot.one
        if hasattr(userbot, "two") and userbot.two in userbot.clients:
            available_clients[2] = userbot.two
        if hasattr(userbot, "three") and userbot.three in userbot.clients:
            available_clients[3] = userbot.three
        return available_clients.get(self.assistant[chat_id])

    async def add_blacklist(self, chat_id: int) -> None:
        if str(chat_id).startswith("-"):
            if chat_id not in self.blacklisted:
                self.blacklisted.append(chat_id)
            bl = await self._kv_get("bl_chats", [])
            if chat_id not in bl:
                bl.append(chat_id)
                await self._kv_set("bl_chats", bl)
        else:
            bl = await self._kv_get("bl_users", [])
            if chat_id not in bl:
                bl.append(chat_id)
                await self._kv_set("bl_users", bl)

    async def del_blacklist(self, chat_id: int) -> None:
        if str(chat_id).startswith("-"):
            if chat_id in self.blacklisted:
                self.blacklisted.remove(chat_id)
            bl = await self._kv_get("bl_chats", [])
            if chat_id in bl:
                bl.remove(chat_id)
                await self._kv_set("bl_chats", bl)
        else:
            bl = await self._kv_get("bl_users", [])
            if chat_id in bl:
                bl.remove(chat_id)
                await self._kv_set("bl_users", bl)

    async def get_blacklisted(self, chat: bool = False) -> list[int]:
        if chat:
            if not self.blacklisted:
                self.blacklisted = list(await self._kv_get("bl_chats", []))
            return self.blacklisted
        return list(await self._kv_get("bl_users", []))

    async def is_chat(self, chat_id: int) -> bool:
        return chat_id in self.chats

    async def add_chat(self, chat_id: int) -> None:
        if not await self.is_chat(chat_id):
            self.chats.append(chat_id)
            await self._exec(
                "INSERT OR IGNORE INTO chats (chat_id) VALUES (?)", (chat_id,)
            )

    async def rm_chat(self, chat_id: int) -> None:
        if await self.is_chat(chat_id):
            self.chats.remove(chat_id)
            await self._exec("DELETE FROM chats WHERE chat_id = ?", (chat_id,))

    async def get_chats(self) -> list:
        if not self.chats:
            rows = await self._fetchall("SELECT chat_id FROM chats")
            self.chats = [r[0] for r in rows]
        return self.chats

    async def set_lang(self, chat_id: int, lang_code: str):
        await self._exec(
            "INSERT INTO lang (chat_id, lang) VALUES (?, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET lang = excluded.lang",
            (chat_id, lang_code),
        )
        self.lang[chat_id] = lang_code

    async def get_lang(self, chat_id: int) -> str:
        if chat_id not in self.lang:
            row = await self._fetchone(
                "SELECT lang FROM lang WHERE chat_id = ?", (chat_id,)
            )
            self.lang[chat_id] = row[0] if row else "en"
        return self.lang[chat_id]

    async def set_user_lang(self, user_id: int, lang_code: str) -> None:
        await self._exec(
            "INSERT INTO user_lang (user_id, lang) VALUES (?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET lang = excluded.lang",
            (user_id, lang_code),
        )
        self.user_lang[user_id] = lang_code

    async def get_user_lang(self, user_id: int) -> str | None:
        if user_id not in self.user_lang:
            row = await self._fetchone(
                "SELECT lang FROM user_lang WHERE user_id = ?", (user_id,)
            )
            self.user_lang[user_id] = row[0] if row else None
        return self.user_lang.get(user_id)

    async def set_maintenance(self, status: bool) -> None:
        self.maintenance = status
        await self._kv_set("maintenance", status)

    async def get_maintenance(self) -> bool:
        self.maintenance = bool(await self._kv_get("maintenance", False))
        return self.maintenance

    async def get_vplay_enabled(self) -> bool:
        val = await self._kv_get("vplay_enabled", None)
        if val is not None:
            self.vplay_enabled = bool(val)
        return self.vplay_enabled

    async def set_vplay_enabled(self, enabled: bool) -> None:
        self.vplay_enabled = enabled
        await self._kv_set("vplay_enabled", enabled)

    async def add_gban(self, user_id: int) -> None:
        gbanned = await self.get_gbanned()
        if user_id not in gbanned:
            gbanned.append(user_id)
            self.gbanned_users = gbanned
            await self._kv_set("gbanned_users", gbanned)

    async def del_gban(self, user_id: int) -> None:
        gbanned = await self.get_gbanned()
        if user_id in gbanned:
            gbanned.remove(user_id)
            self.gbanned_users = gbanned
            await self._kv_set("gbanned_users", gbanned)

    async def get_gbanned(self) -> list[int]:
        if not self.gbanned_users:
            self.gbanned_users = list(await self._kv_get("gbanned_users", []))
        return self.gbanned_users

    async def is_gbanned(self, user_id: int) -> bool:
        return user_id in await self.get_gbanned()

    async def is_logger(self) -> bool:
        return self.logger

    async def get_logger(self) -> bool:
        self.logger = bool(await self._kv_get("logger", False))
        return self.logger

    async def set_logger(self, status: bool) -> None:
        self.logger = status
        await self._kv_set("logger", status)

    async def get_cmode(self, chat_id: int) -> int | None:
        return await self._kv_get(f"cplay_{chat_id}", None)

    async def set_cmode(self, chat_id: int, channel_id: int | None) -> None:
        key = f"cplay_{chat_id}"
        if channel_id is None:
            old = await self._kv_get(key)
            await self._kv_del(key)
            if old is not None:
                await self._kv_del(f"cplay_rev_{old}")
        else:
            await self._kv_set(key, channel_id)
            await self._kv_set(f"cplay_rev_{channel_id}", chat_id)

    async def get_group_for_channel(self, channel_id: int) -> int | None:
        val = await self._kv_get(f"cplay_rev_{channel_id}", None)
        return int(val) if val is not None else None

    async def get_autoleave(self, chat_id: int) -> bool:
        return bool(await self._kv_get(f"autoleave_{chat_id}", False))

    async def set_autoleave(self, chat_id: int, enabled: bool) -> None:
        await self._kv_set(f"autoleave_{chat_id}", enabled)

    async def get_loop(self, chat_id: int) -> int:
        return int(await self._kv_get(f"loop_{chat_id}", 0) or 0)

    async def set_loop(self, chat_id: int, mode: int) -> None:
        if mode == 0:
            await self._kv_del(f"loop_{chat_id}")
        else:
            await self._kv_set(f"loop_{chat_id}", mode)

    async def get_play_mode(self, chat_id: int) -> bool:
        if chat_id not in self.play_mode:
            row = await self._fetchone(
                "SELECT 1 FROM play_mode WHERE chat_id = ?", (chat_id,)
            )
            if row:
                self.play_mode.append(chat_id)
        return chat_id in self.play_mode

    async def set_play_mode(self, chat_id: int, remove: bool = False) -> None:
        if remove:
            if chat_id in self.play_mode:
                self.play_mode.remove(chat_id)
            await self._exec("DELETE FROM play_mode WHERE chat_id = ?", (chat_id,))
        else:
            if chat_id not in self.play_mode:
                self.play_mode.append(chat_id)
            await self._exec(
                "INSERT OR IGNORE INTO play_mode (chat_id) VALUES (?)", (chat_id,)
            )

    async def get_force_mode(self, chat_id: int) -> bool:
        if chat_id not in self.force_mode:
            row = await self._fetchone(
                "SELECT 1 FROM force_mode WHERE chat_id = ?", (chat_id,)
            )
            if row:
                self.force_mode.append(chat_id)
        return chat_id in self.force_mode

    async def set_force_mode(self, chat_id: int, remove: bool = False) -> None:
        if remove:
            if chat_id in self.force_mode:
                self.force_mode.remove(chat_id)
            await self._exec("DELETE FROM force_mode WHERE chat_id = ?", (chat_id,))
        else:
            if chat_id not in self.force_mode:
                self.force_mode.append(chat_id)
            await self._exec(
                "INSERT OR IGNORE INTO force_mode (chat_id) VALUES (?)", (chat_id,)
            )

    async def add_sudo(self, user_id: int) -> None:
        await self._exec(
            "INSERT OR IGNORE INTO sudoers (user_id) VALUES (?)", (user_id,)
        )

    async def del_sudo(self, user_id: int) -> None:
        await self._exec("DELETE FROM sudoers WHERE user_id = ?", (user_id,))

    async def get_sudoers(self) -> list[int]:
        rows = await self._fetchall("SELECT user_id FROM sudoers")
        return [r[0] for r in rows]

    async def is_user(self, user_id: int) -> bool:
        return user_id in self.users

    async def add_user(self, user_id: int) -> None:
        if user_id not in self.users:
            self.users.append(user_id)
            await self._exec(
                "INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,)
            )

    async def rm_user(self, user_id: int) -> None:
        if user_id in self.users:
            self.users.remove(user_id)
            await self._exec("DELETE FROM users WHERE user_id = ?", (user_id,))

    async def get_users(self) -> list:
        if not self.users:
            rows = await self._fetchall("SELECT user_id FROM users")
            self.users = [r[0] for r in rows]
        return self.users

    async def save_session(self, session_string: str, slot: int = 1) -> None:
        await self._exec(
            "INSERT INTO sessions (id, session_string, created_at) VALUES (?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET session_string = excluded.session_string, "
            "created_at = excluded.created_at",
            (slot, session_string, time()),
        )

    async def get_session(self, slot: int = 1) -> str | None:
        row = await self._fetchone(
            "SELECT session_string FROM sessions WHERE id = ?", (slot,)
        )
        return row[0] if row else None

    async def get_all_sessions(self) -> list:
        rows = await self._fetchall(
            "SELECT id, session_string FROM sessions ORDER BY id"
        )
        return [(r[0], r[1]) for r in rows]

    async def migrate_coll(self) -> None:
        await self._kv_set("migrated", {"status": True, "timestamp": time()})

    async def load_cache(self) -> None:
        logger.info("📦 Loading Turso DB cache...")
        doc = await self._kv_get("migrated")
        if not doc:
            await self.migrate_coll()
        await self.get_chats()
        await self.get_users()
        await self.get_blacklisted(chat=True)
        await self.get_logger()
        await self.get_vplay_enabled()
        await self.get_sudoers()
        if not config.SESSION1:
            s1 = await self.get_session(1)
            if s1:
                config.SESSION1 = s1
                logger.info("Loaded STRING_SESSION from Turso DB (slot 1)")
        if not config.SESSION2:
            s2 = await self.get_session(2)
            if s2:
                config.SESSION2 = s2
        if not config.SESSION3:
            s3 = await self.get_session(3)
            if s3:
                config.SESSION3 = s3
        logger.info(
            f"✅ Cache loaded: {len(self.chats)} chats, "
            f"{len(self.users)} users, {len(self.blacklisted)} blacklisted."
        )
